Made By Djelie06#0769

Dit is mijn eerste map.
Alle objects zijn gefreezed op hun plaats dus gaan niet buggen
als je er tegen loopt.